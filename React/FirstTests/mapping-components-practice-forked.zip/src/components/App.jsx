import React from "react";
import Info from "./Info"
import emojipedia from "../emojipedia"

function loopEmojis(props){
  return <Info 
    key={props.key}
    name={props.name}
    emoji={props.emoji}
    meaning={props.meaning}
  />
}

function App() {
  return (
    <div>
      <h1>
        <span>emojipedia</span>
      </h1>
      
      <dl className="dictionary">
        {emojipedia.map(loopEmojis)}
      </dl>
    </div>
  );
}

export default App;
