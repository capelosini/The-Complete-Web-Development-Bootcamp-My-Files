import React from "react";

import contacts from "../contacts.js"

function Contact(props){
  return (
    <div className="card">
        <div className="top">
          <h2 className="name">{props.name}</h2>
          <img
            className="circle-img"
            src={props.img}
            alt="avatar_img"
          />
        </div>
        <div className="bottom">
          <p>{props.number}</p>
          <p>{props.email}</p>
        </div>
    </div>
  )
}

function App() {
  return (
    <div>
      <h1 className="heading">My Contacts</h1>
      <Contact 
        name="Beyonce"
        img="https://blackhistorywall.files.wordpress.com/2010/02/picture-device-independent-bitmap-119.jpg"
        number="+123 456 789"
        email="b@beyonce.com"
      />
      <Contact 
        name={contacts[1].name}
        img={contacts[1].imgURL}
        number={contacts[1].phone}
        email={contacts[1].email}
      />
      <Contact 
        name={contacts[2].name}
        img={contacts[2].imgURL}
        number={contacts[2].phone}
        email={contacts[2].email}
      />
    </div>
  );
}

export default App;
