import React from "react"
import "../public/styles.css"

function App(){
  const year = new Date().getFullYear()
  return(
    <div>
      <nav>
        <header><h1>Keeper</h1></header>
      </nav>
      <div className="note">
        <h1>This is a Note Title</h1>
        <p>Hello world this is a content of a note</p>
      </div>
      <footer>
        <p>Copyright {year}</p>
      </footer>
    </div>
  )
}

export default App